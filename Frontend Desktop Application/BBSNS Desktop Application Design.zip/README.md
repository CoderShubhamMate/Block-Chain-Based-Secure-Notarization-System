
  # BBSNS Desktop Application Design

  This is a code bundle for BBSNS Desktop Application Design. The original project is available at https://www.figma.com/design/oqm0twULLy2r7KfxN19xTS/BBSNS-Desktop-Application-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  